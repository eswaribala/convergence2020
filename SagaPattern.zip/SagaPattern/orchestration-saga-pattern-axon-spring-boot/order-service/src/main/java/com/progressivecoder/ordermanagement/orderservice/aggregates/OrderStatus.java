package com.progressivecoder.ordermanagement.orderservice.aggregates;

public enum OrderStatus {
    CREATED, SHIPPED, REJECTED
}
