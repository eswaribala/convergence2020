package com.progressivecoder.paymentmanagement.paymentservice.aggregates;

public enum InvoiceStatus {

    PAID, PAYMENT_REVERSED
}
