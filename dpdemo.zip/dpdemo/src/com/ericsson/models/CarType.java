package com.ericsson.models;

public enum CarType 
{ 
    MICRO, MINI, LUXURY 
} 
