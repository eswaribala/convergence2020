# Related Blog Posts

* [Using Kafka with Spring Boot](https://reflectoring.io/spring-boot-kafka/)
